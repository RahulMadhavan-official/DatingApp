# dashboard

first run the backend then only run the frontend



cd dashboard

npm install 

npm run dev



backend

cd backend

npm install

npm start
hello
hello