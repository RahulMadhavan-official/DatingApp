import Routing from "./routing/routing";



function App() {
  return (
    <>
    <div className='grid-container'>
      <Routing />
      </div>
    </>
  );
}

export default App;
